# Tabitha Kavyu · Personal Portfolio

A single-page portfolio telling my story: from a Computer Science student at the University of Nairobi, to Google Crowdsource Community Coordinator across six East African countries, to Head of Learner Success at AltSchool Africa supporting 20,000+ learners.

**Live site:** https://tabitha-kavyu.github.io/portfolio/ (update after enabling GitHub Pages)

## What's inside

- `index.html` — the full site. One file, no build step, no dependencies beyond Google Fonts.

## Sections

1. **Story** — my journey in four chapters
2. **The Work, Up Close** — real artifacts: the Community Content Playbook, Cohort Command Centre, revenue recovery campaigns
3. **Speaking** — from OSCAFest Lagos 2020 to CMX Nigeria Summit 2026
4. **Voices** — what learners and colleagues say
5. **Writing & Features** — Google's Crowdsource Spotlight, KamiLimu, TechProfiles Africa, Hustle Yangu Show
6. **Values** — Faith, Encouragement, Authenticity, Impact, Growth

## Deploying with GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Under **Source**, choose **Deploy from a branch**, select `main` and `/ (root)`
4. Your site goes live at `https://YOUR-USERNAME.github.io/REPO-NAME/`

## Editing

Everything lives in `index.html`. Colors and fonts are defined as CSS variables at the top of the `<style>` block. To change the palette, edit `--wine`, `--paper`, and `--brass`.

---

Built on faith, encouragement, and receipts.
